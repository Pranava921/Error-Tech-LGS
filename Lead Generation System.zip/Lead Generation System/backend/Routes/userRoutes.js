const express = require ("express");
const { getUser, postUser } = require("../controllers/userControllers");
const userRoutes= express.Router()

userRoutes.get('/', getUser)
userRoutes.post('/', postUser)

module.exports=userRoutes;