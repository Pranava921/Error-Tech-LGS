import React, {useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
// import { Form } from 'react-router-dom';
import '../styles/LGSstyles.css'

export default function LGSForm() {
  const [formData, setFormData]= useState({name:'', email:'', company: '',message:''});
  const [errors, setErrors] = useState({});
   
    const validate= () =>{
      let errs={};
      if (!formData.name) errs.name = "Name is required";
      if (!formData.email) errs.email ="Email is required";
      else if (!/\S+@\S+\.\S+/.test(formData.email)) errs.email ="Email is invalid";
      setErrors(errs);
      return Object.keys(errs).length ===0;
    };

    const handleChange =(e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        const res = await fetch('http://localhost:5050/user',{
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(formData),
        });

        const result = await res.json();
        alert(result.message);
    };

  return (
    <div className="centered-form d-flex justify-content-center align-items-center vh-100">
    <div className="form-container w-30 p-4 border rounded shadow mt-5">
      <h2 className="heading my-4">Lead Generation Form </h2>
        <form method='post' action="http://localhost:5050/user"onSubmit={handleSubmit}>
          {['name', 'email', 'company', 'message'].map(field =>(
            <div className="mb-4" key={field}>
              <label className='form-label'>
                {field.charAt(0).toUpperCase() + field.slice(1)}
                </label>
              {field === 'message' ? (
                <textarea rows={5} cols={30}
                className={`form-control ${errors[field] ? 'is-valid' :''}`}
                name={field}
                value={formData[field]}
                onChange={handleChange} />
              ) : (
                <input
                type='text'
                className={`form-control ${errors[field] ? 'is-invalid' : ''}`}
                name={field}
                value={formData[field]}
                onChange={handleChange}/>
              )}
              {errors[field] && (
               <div className='invalid-feedback'>{errors[field]}</div>)}
             
            </div>
          ))}
          <div className="d-flex justify-content-center">
          <button type='submit' className='btn btn-primary'>Submit</button>
          </div>
        </form>
    </div>
    </div>
  )
}
