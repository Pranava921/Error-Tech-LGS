import React from 'react';
import LGSForm from './components/LGSForm';

function App() {

  return (
  <div>
    <LGSForm />
  </div>
    
  )
}

export default App
